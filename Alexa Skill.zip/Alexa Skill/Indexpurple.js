var Alexa = require('alexa-sdk');

exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context);


    alexa.registerHandlers(handlers);
    alexa.execute();
};

var handlers = {
    'LaunchRequest': function () {
        this.emit('GetNewFactIntent');
    },

    'GetNewFactIntent': function () {
        var say = 'Hello Sowmya! This fact is to reiterate the importance of women in Science and Technology. ' + getFact();
        this.emit(':tell', say );
    },

    'AMAZON.HelpIntent': function () {
         this.emit(':ask', 'Women in Science!');
     },

     'AMAZON.CancelIntent': function () {
         this.emit(':tell', 'Goodbye ');
     },

     'AMAZON.StopIntent': function () {
         this.emit(':tell', 'Goodbye ');
     }
};

//  helper functions  ===================================================================


function getFact() {
    var myFacts = [
    '<audio src=\"https://s3.amazonaws.com/t9hack-website-mp3/7b799e9e-c6a8-4a77-9c63-579f9110d8f2.mp3" />\'',
    '<audio src=\"https://s3.amazonaws.com/t9hack-website-mp3/f4217fb0-1d60-4593-9e69-530376362cbe.mp3" />\'',
    '<audio src=\"https://s3.amazonaws.com/t9hack-website-mp3/7fee8eb1-9a5d-4504-85b6-d1852b240468.mp3" />\'',
	'<audio src=\"https://s3.amazonaws.com/t9hack-website-mp3/d0fcac04-d01c-4f78-a686-b96edb23440f.mp3" />\'',
	'<audio src=\"https://s3.amazonaws.com/t9hack-website-mp3/d88dcb3b-20cf-4c7a-bdc7-ea83c8d1390c.mp3" />\''
        ]

    var newFact = randomPhrase(myFacts);

    return newFact;
}

function randomPhrase(array) {
    // the argument is an array [] of words or phrases
    var i = 0;
    i = Math.floor(Math.random() * array.length);
    return(array[i]);
}