var Alexa = require('alexa-sdk');

exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context);


    alexa.registerHandlers(handlers);
    alexa.execute();
};

var handlers = {
    'LaunchRequest': function () {
        this.emit('GetNewFactIntent');
    },

    'GetNewFactIntent': function () {
        var say = 'Hello Sowmya! Here is your physics fact of the day. ' + getFact();
        this.emit(':tell', say );
    },

    'AMAZON.HelpIntent': function () {
         this.emit(':ask', 'I am your physics tutor!');
     },

     'AMAZON.CancelIntent': function () {
         this.emit(':tell', 'Goodbye ');
     },

     'AMAZON.StopIntent': function () {
         this.emit(':tell', 'Goodbye ');
     }
};

//  helper functions  ===================================================================


function getFact() {
    var myFacts = [
    '<audio src=\"https://s3.amazonaws.com/t9hack-website-mp3/a41b921d-9ba2-4e49-a31c-3107565dda3d.mp3" />\'',
    '<audio src=\"https://s3.amazonaws.com/t9hack-website-mp3/ac2c14a9-2c6c-45db-8c78-7d9bd23338db.mp3" />\'',
    '<audio src=\"https://s3.amazonaws.com/t9hack-website-mp3/4d68a8e0-5a99-49ca-b8ae-c23df03beb68.mp3" />\'',
	'<audio src=\"https://s3.amazonaws.com/t9hack-website-mp3/f08336a6-85ae-463b-89b9-89855e076de9.mp3" />\'',
	'<audio src=\"https://s3.amazonaws.com/t9hack-website-mp3/6c77e075-1c02-4207-a0d1-23f543d697e5.mp3" />\''
        ]

    var newFact = randomPhrase(myFacts);

    return newFact;
}

function randomPhrase(array) {
    // the argument is an array [] of words or phrases
    var i = 0;
    i = Math.floor(Math.random() * array.length);
    return(array[i]);
}